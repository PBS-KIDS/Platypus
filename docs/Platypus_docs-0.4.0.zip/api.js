YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "platypus.AABB",
        "platypus.CollisionData",
        "platypus.CollisionShape",
        "platypus.Component",
        "platypus.Entity",
        "platypus.Game",
        "platypus.Scene",
        "platypus.Vector",
        "platypus.components.\"Camera\" Component",
        "platypus.components.\"CollisionBasic\" Component",
        "platypus.components.\"CollisionTiles\" Component",
        "platypus.components.\"HandlerCollision\" Component",
        "platypus.components.\"HandlerLogic\" Component",
        "platypus.components.\"LogicDestroyMe\" Component",
        "platypus.components.\"Motion\" Component",
        "platypus.components.\"Mover\" Component",
        "platypus.components.\"Orientation\" Component",
        "platypus.components.\"TiledLoader\" Component",
        "platypus.components.\"XHR\" Component",
        "platypus.components.AIChaser",
        "platypus.components.AIPacer"
    ],
    "modules": [
        "Platypus"
    ],
    "allModules": [
        {
            "displayName": "Platypus",
            "name": "Platypus"
        }
    ]
} };
});