YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "platypus.AABB",
        "platypus.CollisionData",
        "platypus.CollisionShape",
        "platypus.Component",
        "platypus.Entity",
        "platypus.Game",
        "platypus.Messenger",
        "platypus.PIXIAnimation",
        "platypus.PlatypusPlugin",
        "platypus.Scene",
        "platypus.Vector",
        "platypus.components.AIChaser",
        "platypus.components.AIPacer",
        "platypus.components.AssetLoader",
        "platypus.components.Audio",
        "platypus.components.AudioMobile",
        "platypus.components.AudioSFX",
        "platypus.components.AudioVO",
        "platypus.components.Camera",
        "platypus.components.CameraFollowMe",
        "platypus.components.CollisionBasic",
        "platypus.components.CollisionFilter",
        "platypus.components.CollisionGroup",
        "platypus.components.CollisionTiles",
        "platypus.components.ComponentSwitcher",
        "platypus.components.Counter",
        "platypus.components.EntityContainer",
        "platypus.components.HandlerCollision",
        "platypus.components.HandlerController",
        "platypus.components.HandlerLogic",
        "platypus.components.HandlerRender",
        "platypus.components.LevelBuilder",
        "platypus.components.LogicAngularMovement",
        "platypus.components.LogicAttachment",
        "platypus.components.LogicCanvasButton",
        "platypus.components.LogicDestroyMe",
        "platypus.components.Motion",
        "platypus.components.Mover",
        "platypus.components.NodeMap",
        "platypus.components.NodeResident",
        "platypus.components.Orientation",
        "platypus.components.RandomEvents",
        "platypus.components.RelayFamily",
        "platypus.components.RelayGame",
        "platypus.components.RelayLinker",
        "platypus.components.RelayParent",
        "platypus.components.RelaySelf",
        "platypus.components.RenderProgress",
        "platypus.components.RenderSprite",
        "platypus.components.RenderTiles",
        "platypus.components.TiledLoader",
        "platypus.components.VoiceOver",
        "platypus.components.XHR"
    ],
    "modules": [
        "Platypus"
    ],
    "allModules": [
        {
            "displayName": "Platypus",
            "name": "Platypus"
        }
    ]
} };
});