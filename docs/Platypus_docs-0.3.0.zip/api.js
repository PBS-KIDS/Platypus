YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "\"ai-chaser\" Component",
        "\"ai-pacer\" Component",
        "\"camera\" Component",
        "\"collision-basic\" Component",
        "\"collision-tiles\" Component",
        "\"handler-collision\" Component",
        "\"handler-logic\" Component",
        "\"logic-destroy-me\" Component",
        "\"motion\" Component",
        "\"mover\" Component",
        "\"orientation\" Component",
        "\"tiled-loader\" Component",
        "\"xhr\" Component",
        "AABB",
        "CollisionData",
        "CollisionShape",
        "Component",
        "Entity",
        "Game",
        "Scene",
        "Vector"
    ],
    "modules": [],
    "allModules": []
} };
});