YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "platypus.AABB",
        "platypus.CollisionData",
        "platypus.CollisionShape",
        "platypus.Component",
        "platypus.Entity",
        "platypus.Game",
        "platypus.Scene",
        "platypus.Vector",
        "platypus.components.\"CollisionTiles\" Component",
        "platypus.components.\"HandlerCollision\" Component",
        "platypus.components.\"HandlerLogic\" Component",
        "platypus.components.\"LogicDestroyMe\" Component",
        "platypus.components.\"Motion\" Component",
        "platypus.components.\"Mover\" Component",
        "platypus.components.\"Orientation\" Component",
        "platypus.components.\"TiledLoader\" Component",
        "platypus.components.\"XHR\" Component",
        "platypus.components.AIChaser",
        "platypus.components.AIPacer",
        "platypus.components.AssetLoader",
        "platypus.components.Audio",
        "platypus.components.AudioMixer",
        "platypus.components.AudioMobile",
        "platypus.components.Camera",
        "platypus.components.CameraFollowMe",
        "platypus.components.CollisionBasic",
        "platypus.components.CollisionFilter",
        "platypus.components.CollisionGroup",
        "platypus.components.ComponentSwitcher",
        "platypus.components.Counter",
        "platypus.components.HandlerController"
    ],
    "modules": [
        "Platypus"
    ],
    "allModules": [
        {
            "displayName": "Platypus",
            "name": "Platypus"
        }
    ]
} };
});