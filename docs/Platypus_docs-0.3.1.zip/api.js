YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "platypus.AABB",
        "platypus.CollisionData",
        "platypus.CollisionShape",
        "platypus.Component",
        "platypus.Entity",
        "platypus.Game",
        "platypus.Scene",
        "platypus.Vector",
        "platypus.components.\"ai-pacer\" Component",
        "platypus.components.\"camera\" Component",
        "platypus.components.\"collision-basic\" Component",
        "platypus.components.\"collision-tiles\" Component",
        "platypus.components.\"handler-collision\" Component",
        "platypus.components.\"handler-logic\" Component",
        "platypus.components.\"logic-destroy-me\" Component",
        "platypus.components.\"motion\" Component",
        "platypus.components.\"mover\" Component",
        "platypus.components.\"orientation\" Component",
        "platypus.components.\"tiled-loader\" Component",
        "platypus.components.\"xhr\" Component",
        "platypus.components.ai-chaser"
    ],
    "modules": [
        "Platypus"
    ],
    "allModules": [
        {
            "displayName": "Platypus",
            "name": "Platypus"
        }
    ]
} };
});